import mongoose, { Schema } from 'mongoose'

const espacioSchema = new Schema({
  nombre: {
    type: String
  },
  plantaciones: [{
    type: Schema.Types.ObjectId,
    ref: 'plantacion'
  }],
  dimension: {
    type: String
  },
  huerto: {
    type: Schema.Types.ObjectId,
    ref: 'huerto'
  }
}, {
  timestamps: true,
  toJSON: {
    virtuals: true,
    transform: (obj, ret) => { delete ret._id }
  }
})

espacioSchema.methods = {
  view (full) {
    const view = {
      // simple view
      id: this.id,
      nombre: this.nombre,
      plantaciones: this.plantaciones,
      dimension: this.dimension,
      huerto: this.huerto,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    }

    return full ? {
      ...view
      // add properties for a full view
    } : view
  }
}

const model = mongoose.model('Espacio', espacioSchema)

export const schema = model.schema
export default model
