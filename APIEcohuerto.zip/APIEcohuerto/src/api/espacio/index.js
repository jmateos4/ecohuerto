import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { create, index, show, update, destroy } from './controller'
import { schema } from './model'
import { token } from '../../services/passport'
export Espacio, { schema } from './model'

const router = new Router()
const { nombre, plantaciones, dimension, huerto } = schema.tree

/**
 * @api {post} /espacios Create espacio
 * @apiName CreateEspacio
 * @apiGroup Espacio
 * @apiParam nombre Espacio's nombre.
 * @apiParam plantaciones Espacio's plantaciones.
 * @apiParam dimension Espacio's dimension.
 * @apiParam huerto Espacio's huerto.
 * @apiSuccess {Object} espacio Espacio's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Espacio not found.
 */
router.post('/',
  token({ required: true }),
  body({ nombre, plantaciones, dimension, huerto }),
  create)

/**
 * @api {get} /espacios Retrieve espacios
 * @apiName RetrieveEspacios
 * @apiGroup Espacio
 * @apiUse listParams
 * @apiSuccess {Number} count Total amount of espacios.
 * @apiSuccess {Object[]} rows List of espacios.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 */
router.get('/',
  token({ required: true }),
  query(),
  index)

/**
 * @api {get} /espacios/:id Retrieve espacio
 * @apiName RetrieveEspacio
 * @apiGroup Espacio
 * @apiSuccess {Object} espacio Espacio's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Espacio not found.
 */
router.get('/:id',
  token({ required: true }),
  show)

/**
 * @api {put} /espacios/:id Update espacio
 * @apiName UpdateEspacio
 * @apiGroup Espacio
 * @apiParam nombre Espacio's nombre.
 * @apiParam plantaciones Espacio's plantaciones.
 * @apiParam dimension Espacio's dimension.
 * @apiParam huerto Espacio's huerto.
 * @apiSuccess {Object} espacio Espacio's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Espacio not found.
 */
router.put('/:id',
  token({ required: true }), 
  body({ nombre, plantaciones, dimension, huerto }),
  update)

/**
 * @api {delete} /espacios/:id Delete espacio
 * @apiName DeleteEspacio
 * @apiGroup Espacio
 * @apiSuccess (Success 204) 204 No Content.
 * @apiError 404 Espacio not found.
 */
router.delete('/:id',
  token({ required: true }),
  destroy)

export default router
