import { Huerto } from '.'

let huerto

beforeEach(async () => {
  huerto = await Huerto.create({ nombre: 'test', espacio: 'test', localizacion: 'test', user: 'test' })
})

describe('view', () => {
  it('returns simple view', () => {
    const view = huerto.view()
    expect(typeof view).toBe('object')
    expect(view.id).toBe(huerto.id)
    expect(view.nombre).toBe(huerto.nombre)
    expect(view.espacio).toBe(huerto.espacio)
    expect(view.localizacion).toBe(huerto.localizacion)
    expect(view.user).toBe(huerto.user)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })

  it('returns full view', () => {
    const view = huerto.view(true)
    expect(typeof view).toBe('object')
    expect(view.id).toBe(huerto.id)
    expect(view.nombre).toBe(huerto.nombre)
    expect(view.espacio).toBe(huerto.espacio)
    expect(view.localizacion).toBe(huerto.localizacion)
    expect(view.user).toBe(huerto.user)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })
})
