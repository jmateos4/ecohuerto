import mongoose, { Schema } from 'mongoose'

const huertoSchema = new Schema({
  nombre: {
    type: String
  },
  espacio: {
    type: Schema.Types.ObjectId,
    ref: 'espacio'
  },
  localizacion: {
    type: String
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: 'user'
  }
}, {
  timestamps: true,
  toJSON: {
    virtuals: true,
    transform: (obj, ret) => { delete ret._id }
  }
})

huertoSchema.methods = {
  view (full) {
    const view = {
      // simple view
      id: this.id,
      nombre: this.nombre,
      espacio: this.espacio,
      localizacion: this.localizacion,
      user: this.user,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    }

    return full ? {
      ...view
      // add properties for a full view
    } : view
  }
}

const model = mongoose.model('Huerto', huertoSchema)

export const schema = model.schema
export default model
