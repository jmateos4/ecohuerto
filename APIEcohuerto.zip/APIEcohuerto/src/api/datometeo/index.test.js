import request from 'supertest'
import { apiRoot } from '../../config'
import express from '../../services/express'
import routes, { Datometeo } from '.'

const app = () => express(apiRoot, routes)

let datometeo

beforeEach(async () => {
  datometeo = await Datometeo.create({})
})

test('POST /datosmeteo 201', async () => {
  const { status, body } = await request(app())
    .post(`${apiRoot}`)
    .send({ temperatura: 'test', viento: 'test', humedad: 'test', problluvia: 'test' })
  expect(status).toBe(201)
  expect(typeof body).toEqual('object')
  expect(body.temperatura).toEqual('test')
  expect(body.viento).toEqual('test')
  expect(body.humedad).toEqual('test')
  expect(body.problluvia).toEqual('test')
})

test('GET /datosmeteo 200', async () => {
  const { status, body } = await request(app())
    .get(`${apiRoot}`)
  expect(status).toBe(200)
  expect(Array.isArray(body.rows)).toBe(true)
  expect(Number.isNaN(body.count)).toBe(false)
})

test('GET /datosmeteo/:id 200', async () => {
  const { status, body } = await request(app())
    .get(`${apiRoot}/${datometeo.id}`)
  expect(status).toBe(200)
  expect(typeof body).toEqual('object')
  expect(body.id).toEqual(datometeo.id)
})

test('GET /datosmeteo/:id 404', async () => {
  const { status } = await request(app())
    .get(apiRoot + '/123456789098765432123456')
  expect(status).toBe(404)
})

test('PUT /datosmeteo/:id 200', async () => {
  const { status, body } = await request(app())
    .put(`${apiRoot}/${datometeo.id}`)
    .send({ temperatura: 'test', viento: 'test', humedad: 'test', problluvia: 'test' })
  expect(status).toBe(200)
  expect(typeof body).toEqual('object')
  expect(body.id).toEqual(datometeo.id)
  expect(body.temperatura).toEqual('test')
  expect(body.viento).toEqual('test')
  expect(body.humedad).toEqual('test')
  expect(body.problluvia).toEqual('test')
})

test('PUT /datosmeteo/:id 404', async () => {
  const { status } = await request(app())
    .put(apiRoot + '/123456789098765432123456')
    .send({ temperatura: 'test', viento: 'test', humedad: 'test', problluvia: 'test' })
  expect(status).toBe(404)
})

test('DELETE /datosmeteo/:id 204', async () => {
  const { status } = await request(app())
    .delete(`${apiRoot}/${datometeo.id}`)
  expect(status).toBe(204)
})

test('DELETE /datosmeteo/:id 404', async () => {
  const { status } = await request(app())
    .delete(apiRoot + '/123456789098765432123456')
  expect(status).toBe(404)
})
