import { Datometeo } from '.'

let datometeo

beforeEach(async () => {
  datometeo = await Datometeo.create({ temperatura: 'test', viento: 'test', humedad: 'test', problluvia: 'test' })
})

describe('view', () => {
  it('returns simple view', () => {
    const view = datometeo.view()
    expect(typeof view).toBe('object')
    expect(view.id).toBe(datometeo.id)
    expect(view.temperatura).toBe(datometeo.temperatura)
    expect(view.viento).toBe(datometeo.viento)
    expect(view.humedad).toBe(datometeo.humedad)
    expect(view.problluvia).toBe(datometeo.problluvia)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })

  it('returns full view', () => {
    const view = datometeo.view(true)
    expect(typeof view).toBe('object')
    expect(view.id).toBe(datometeo.id)
    expect(view.temperatura).toBe(datometeo.temperatura)
    expect(view.viento).toBe(datometeo.viento)
    expect(view.humedad).toBe(datometeo.humedad)
    expect(view.problluvia).toBe(datometeo.problluvia)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })
})
