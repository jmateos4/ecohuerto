import mongoose, { Schema } from 'mongoose'

const datometeoSchema = new Schema({
  temperatura: {
    type: String
  },
  viento: {
    type: String
  },
  humedad: {
    type: String
  },
  problluvia: {
    type: String
  }
}, {
  timestamps: true,
  toJSON: {
    virtuals: true,
    transform: (obj, ret) => { delete ret._id }
  }
})

datometeoSchema.methods = {
  view (full) {
    const view = {
      // simple view
      id: this.id,
      temperatura: this.temperatura,
      viento: this.viento,
      humedad: this.humedad,
      problluvia: this.problluvia,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    }

    return full ? {
      ...view
      // add properties for a full view
    } : view
  }
}

const model = mongoose.model('Datometeo', datometeoSchema)

export const schema = model.schema
export default model
