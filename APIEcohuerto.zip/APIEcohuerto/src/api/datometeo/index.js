import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { create, index, show, update, destroy } from './controller'
import { schema } from './model'
import { token } from '../../services/passport'
export Datometeo, { schema } from './model'

const router = new Router()
const { temperatura, viento, humedad, problluvia } = schema.tree

/**
 * @api {post} /datosmeteo Create datometeo
 * @apiName CreateDatometeo
 * @apiGroup Datometeo
 * @apiParam temperatura Datometeo's temperatura.
 * @apiParam viento Datometeo's viento.
 * @apiParam humedad Datometeo's humedad.
 * @apiParam problluvia Datometeo's problluvia.
 * @apiSuccess {Object} datometeo Datometeo's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Datometeo not found.
 */
router.post('/',
  token({ required: true }),
  body({ temperatura, viento, humedad, problluvia }),
  create)

/**
 * @api {get} /datosmeteo Retrieve datometeos
 * @apiName RetrieveDatometeos
 * @apiGroup Datometeo
 * @apiUse listParams
 * @apiSuccess {Number} count Total amount of datometeos.
 * @apiSuccess {Object[]} rows List of datometeos.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 */
router.get('/',
  token({ required: true }),
  query(),
  index)

/**
 * @api {get} /datosmeteo/:id Retrieve datometeo
 * @apiName RetrieveDatometeo
 * @apiGroup Datometeo
 * @apiSuccess {Object} datometeo Datometeo's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Datometeo not found.
 */
router.get('/:id',
  token({ required: true }),
  show)

/**
 * @api {put} /datosmeteo/:id Update datometeo
 * @apiName UpdateDatometeo
 * @apiGroup Datometeo
 * @apiParam temperatura Datometeo's temperatura.
 * @apiParam viento Datometeo's viento.
 * @apiParam humedad Datometeo's humedad.
 * @apiParam problluvia Datometeo's problluvia.
 * @apiSuccess {Object} datometeo Datometeo's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Datometeo not found.
 */
router.put('/:id',
  token({ required: true }),
  body({ temperatura, viento, humedad, problluvia }),
  update)

/**
 * @api {delete} /datosmeteo/:id Delete datometeo
 * @apiName DeleteDatometeo
 * @apiGroup Datometeo
 * @apiSuccess (Success 204) 204 No Content.
 * @apiError 404 Datometeo not found.
 */
router.delete('/:id',
  token({ required: true }),
  destroy)

export default router
