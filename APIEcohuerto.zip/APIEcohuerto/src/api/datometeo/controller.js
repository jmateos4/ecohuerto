import { success, notFound } from '../../services/response/'
import { Datometeo } from '.'

export const create = ({ bodymen: { body } }, res, next) =>
  Datometeo.create(body)
    .then((datometeo) => datometeo.view(true))
    .then(success(res, 201))
    .catch(next)

export const index = ({ querymen: { query, select, cursor } }, res, next) =>
  Datometeo.count(query)
    .then(count => Datometeo.find(query, select, cursor)
      .then((datometeos) => ({
        count,
        rows: datometeos.map((datometeo) => datometeo.view())
      }))
    )
    .then(success(res))
    .catch(next)

export const show = ({ params }, res, next) =>
  Datometeo.findById(params.id)
    .then(notFound(res))
    .then((datometeo) => datometeo ? datometeo.view() : null)
    .then(success(res))
    .catch(next)

export const update = ({ bodymen: { body }, params }, res, next) =>
  Datometeo.findById(params.id)
    .then(notFound(res))
    .then((datometeo) => datometeo ? Object.assign(datometeo, body).save() : null)
    .then((datometeo) => datometeo ? datometeo.view(true) : null)
    .then(success(res))
    .catch(next)

export const destroy = ({ params }, res, next) =>
  Datometeo.findById(params.id)
    .then(notFound(res))
    .then((datometeo) => datometeo ? datometeo.remove() : null)
    .then(success(res, 204))
    .catch(next)
