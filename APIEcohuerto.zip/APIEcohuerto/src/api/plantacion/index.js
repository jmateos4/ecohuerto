import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { create, index, show, update, destroy } from './controller'
import { schema } from './model'
import { token } from '../../services/passport'
export Plantacion, { schema } from './model'

const router = new Router()
const { nombre, tipo, espacio } = schema.tree

/**
 * @api {post} /plantaciones Create plantacion
 * @apiName CreatePlantacion
 * @apiGroup Plantacion
 * @apiParam nombre Plantacion's nombre.
 * @apiParam tipo Plantacion's tipo.
 * @apiParam espacio Plantacion's espacio.
 * @apiSuccess {Object} plantacion Plantacion's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Plantacion not found.
 */
router.post('/',
  token({ required: true }),
  body({ nombre, tipo, espacio }),
  create)

/**
 * @api {get} /plantaciones Retrieve plantacions
 * @apiName RetrievePlantacions
 * @apiGroup Plantacion
 * @apiUse listParams
 * @apiSuccess {Number} count Total amount of plantacions.
 * @apiSuccess {Object[]} rows List of plantacions.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 */
router.get('/',
  token({ required: true }),
  query(),
  index)

/**
 * @api {get} /plantaciones/:id Retrieve plantacion
 * @apiName RetrievePlantacion
 * @apiGroup Plantacion
 * @apiSuccess {Object} plantacion Plantacion's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Plantacion not found.
 */
router.get('/:id',
  token({ required: true }),
  show)

/**
 * @api {put} /plantaciones/:id Update plantacion
 * @apiName UpdatePlantacion
 * @apiGroup Plantacion
 * @apiParam nombre Plantacion's nombre.
 * @apiParam tipo Plantacion's tipo.
 * @apiParam espacio Plantacion's espacio.
 * @apiSuccess {Object} plantacion Plantacion's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Plantacion not found.
 */
router.put('/:id',
  token({ required: true }),
  body({ nombre, tipo, espacio }),
  update)

/**
 * @api {delete} /plantaciones/:id Delete plantacion
 * @apiName DeletePlantacion
 * @apiGroup Plantacion
 * @apiSuccess (Success 204) 204 No Content.
 * @apiError 404 Plantacion not found.
 */
router.delete('/:id',
  token({ required: true }),
  destroy)

export default router
