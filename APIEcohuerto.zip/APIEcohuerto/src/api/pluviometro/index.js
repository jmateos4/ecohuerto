import { Router } from 'express'
import { middleware as query } from 'querymen'
import { middleware as body } from 'bodymen'
import { create, index, show, update, destroy } from './controller'
import { schema } from './model'
import { token } from '../../services/passport'
export Pluviometro, { schema } from './model'

const router = new Router()
const { lectura } = schema.tree

/**
 * @api {post} /pluviometros Create pluviometro
 * @apiName CreatePluviometro
 * @apiGroup Pluviometro
 * @apiParam lectura Pluviometro's lectura.
 * @apiSuccess {Object} pluviometro Pluviometro's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Pluviometro not found.
 */
router.post('/',
  token({ required: true }),
  body({ lectura }),
  create)

/**
 * @api {get} /pluviometros Retrieve pluviometros
 * @apiName RetrievePluviometros
 * @apiGroup Pluviometro
 * @apiUse listParams
 * @apiSuccess {Number} count Total amount of pluviometros.
 * @apiSuccess {Object[]} rows List of pluviometros.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 */
router.get('/',
  token({ required: true }),
  query(),
  index)

/**
 * @api {get} /pluviometros/:id Retrieve pluviometro
 * @apiName RetrievePluviometro
 * @apiGroup Pluviometro
 * @apiSuccess {Object} pluviometro Pluviometro's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Pluviometro not found.
 */
router.get('/:id',
  token({ required: true }),
  show)

/**
 * @api {put} /pluviometros/:id Update pluviometro
 * @apiName UpdatePluviometro
 * @apiGroup Pluviometro
 * @apiParam lectura Pluviometro's lectura.
 * @apiSuccess {Object} pluviometro Pluviometro's data.
 * @apiError {Object} 400 Some parameters may contain invalid values.
 * @apiError 404 Pluviometro not found.
 */
router.put('/:id',
  token({ required: true }),
  body({ lectura }),
  update)

/**
 * @api {delete} /pluviometros/:id Delete pluviometro
 * @apiName DeletePluviometro
 * @apiGroup Pluviometro
 * @apiSuccess (Success 204) 204 No Content.
 * @apiError 404 Pluviometro not found.
 */
router.delete('/:id',
  token({ required: true }),
  destroy)

export default router
