import { success, notFound } from '../../services/response/'
import { Pluviometro } from '.'

export const create = ({ bodymen: { body } }, res, next) =>
  Pluviometro.create(body)
    .then((pluviometro) => pluviometro.view(true))
    .then(success(res, 201))
    .catch(next)

export const index = ({ querymen: { query, select, cursor } }, res, next) =>
  Pluviometro.count(query)
    .then(count => Pluviometro.find(query, select, cursor)
      .then((pluviometros) => ({
        count,
        rows: pluviometros.map((pluviometro) => pluviometro.view())
      }))
    )
    .then(success(res))
    .catch(next)

export const show = ({ params }, res, next) =>
  Pluviometro.findById(params.id)
    .then(notFound(res))
    .then((pluviometro) => pluviometro ? pluviometro.view() : null)
    .then(success(res))
    .catch(next)

export const update = ({ bodymen: { body }, params }, res, next) =>
  Pluviometro.findById(params.id)
    .then(notFound(res))
    .then((pluviometro) => pluviometro ? Object.assign(pluviometro, body).save() : null)
    .then((pluviometro) => pluviometro ? pluviometro.view(true) : null)
    .then(success(res))
    .catch(next)

export const destroy = ({ params }, res, next) =>
  Pluviometro.findById(params.id)
    .then(notFound(res))
    .then((pluviometro) => pluviometro ? pluviometro.remove() : null)
    .then(success(res, 204))
    .catch(next)
