import request from 'supertest'
import { apiRoot } from '../../config'
import express from '../../services/express'
import routes, { Pluviometro } from '.'

const app = () => express(apiRoot, routes)

let pluviometro

beforeEach(async () => {
  pluviometro = await Pluviometro.create({})
})

test('POST /pluviometros 201', async () => {
  const { status, body } = await request(app())
    .post(`${apiRoot}`)
    .send({ lectura: 'test' })
  expect(status).toBe(201)
  expect(typeof body).toEqual('object')
  expect(body.lectura).toEqual('test')
})

test('GET /pluviometros 200', async () => {
  const { status, body } = await request(app())
    .get(`${apiRoot}`)
  expect(status).toBe(200)
  expect(Array.isArray(body.rows)).toBe(true)
  expect(Number.isNaN(body.count)).toBe(false)
})

test('GET /pluviometros/:id 200', async () => {
  const { status, body } = await request(app())
    .get(`${apiRoot}/${pluviometro.id}`)
  expect(status).toBe(200)
  expect(typeof body).toEqual('object')
  expect(body.id).toEqual(pluviometro.id)
})

test('GET /pluviometros/:id 404', async () => {
  const { status } = await request(app())
    .get(apiRoot + '/123456789098765432123456')
  expect(status).toBe(404)
})

test('PUT /pluviometros/:id 200', async () => {
  const { status, body } = await request(app())
    .put(`${apiRoot}/${pluviometro.id}`)
    .send({ lectura: 'test' })
  expect(status).toBe(200)
  expect(typeof body).toEqual('object')
  expect(body.id).toEqual(pluviometro.id)
  expect(body.lectura).toEqual('test')
})

test('PUT /pluviometros/:id 404', async () => {
  const { status } = await request(app())
    .put(apiRoot + '/123456789098765432123456')
    .send({ lectura: 'test' })
  expect(status).toBe(404)
})

test('DELETE /pluviometros/:id 204', async () => {
  const { status } = await request(app())
    .delete(`${apiRoot}/${pluviometro.id}`)
  expect(status).toBe(204)
})

test('DELETE /pluviometros/:id 404', async () => {
  const { status } = await request(app())
    .delete(apiRoot + '/123456789098765432123456')
  expect(status).toBe(404)
})
