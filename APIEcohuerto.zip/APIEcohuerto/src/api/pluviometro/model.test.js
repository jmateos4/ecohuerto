import { Pluviometro } from '.'

let pluviometro

beforeEach(async () => {
  pluviometro = await Pluviometro.create({ lectura: 'test' })
})

describe('view', () => {
  it('returns simple view', () => {
    const view = pluviometro.view()
    expect(typeof view).toBe('object')
    expect(view.id).toBe(pluviometro.id)
    expect(view.lectura).toBe(pluviometro.lectura)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })

  it('returns full view', () => {
    const view = pluviometro.view(true)
    expect(typeof view).toBe('object')
    expect(view.id).toBe(pluviometro.id)
    expect(view.lectura).toBe(pluviometro.lectura)
    expect(view.createdAt).toBeTruthy()
    expect(view.updatedAt).toBeTruthy()
  })
})
